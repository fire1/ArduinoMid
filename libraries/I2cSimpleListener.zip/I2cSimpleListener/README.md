# I2cSimpleListener
Listen I2C messages over I2C network